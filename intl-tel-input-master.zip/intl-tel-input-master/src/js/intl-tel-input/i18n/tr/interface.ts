//* Turkish. Translated by: Google Translate.
import { I18n } from "../types";

const interfaceTranslations: I18n = {
  selectedCountryAriaLabel: "Seçilen ülke",
  noCountrySelected: "Hiçbir ülke seçilmedi",
  countryListAriaLabel: "Ülke listesi",
  searchPlaceholder: "Aramak",
  zeroSearchResults: "Sonuç bulunamadı",
  oneSearchResult: "1 sonuç bulundu",
  multipleSearchResults: "${count} sonuç bulundu",
  
  // additional countries (not supported by country-list library)
  ac: "Yükselme adası",
  xk: "Kosova",
};

export default interfaceTranslations;