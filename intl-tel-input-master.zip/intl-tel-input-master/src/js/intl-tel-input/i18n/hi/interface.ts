//* Hindi. Translated by: Google Translate.
import { I18n } from "../types";

const interfaceTranslations: I18n = {
  selectedCountryAriaLabel: "चयनित देश",
  noCountrySelected: "कोई देश चयनित नहीं",
  countryListAriaLabel: "देशों की सूची",
  searchPlaceholder: "खोज",
  zeroSearchResults: "कोई परिणाम नहीं मिला",
  oneSearchResult: "1 परिणाम मिला",
  multipleSearchResults: "${count} परिणाम मिले",
  
  // additional countries (not supported by country-list library)
  ac: "असेंशन द्वीप",
  xk: "कोसोवो",
};

export default interfaceTranslations;