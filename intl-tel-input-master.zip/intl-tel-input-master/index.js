module.exports = require("./build/js/intlTelInput");
